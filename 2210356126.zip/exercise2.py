def mail(x):
    if "@" in x and "." in x:
        return True
    else:
        return False
text = input("Please enter your email: ")
print(mail(text))