import random
n = random.randint(1, 100)
g = int(input("Enter your guess: "))
while g != n:
    if g > n:
        g = int(input("Too high! Try again: "))
    else:
        g = int(input("Too low! Try again: "))
print("Correct, you win!")